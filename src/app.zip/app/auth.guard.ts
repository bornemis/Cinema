import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
 @Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
   constructor(
    private authService: AuthService,
    private router: Router
  ) {
   }
   canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
     if (this.authService.isLoggedIn) {
      if (next.data && next.data.roles) {
        if (next.data.roles.includes(this.authService.user.role)) {
          return true;
        } else {
          return false;
        }
      }
      else return true
    }else{
      console.log("Nincs bejelentkezve\n")
      console.log(next.url.join(''))
      if(!next.url.join('').includes("add")){
        if (next.data && next.data.roles) {
          if (next.data.roles.includes('GUEST')) {
            console.log(next.url.join(''))
            console.log('Vendeg\n')
            return true;
          } 
        }
      }
  }
    console.log(state.url)
     this.authService.redirectUrl = state.url;
    this.router.navigate(['/login']);
    return false;
  }
}
