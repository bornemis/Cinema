export class User {
    id=null;
    userName: string='';
    password: string='';
    enabled: boolean=true;
    role: string='';

}
