export class Chair {
    id=null;
    roomName: string='';
    movieTitle: string='';
    rowNumber: number=0;
    columnNumber: number=0;
    customerName: string='';
    customerEmail: string='';
    ticketType: string='';
    status: string='';
}
