
export class Screening {
    id=null;
    movieTitle: string='';
    roomName: string='';
    startTime: string='';
    movieDurationInMin: number=0;
    dType: string='';
    screeningLanguage: string='';
    subscription: string='';
}
