export class Room {
    id=null;
    roomName: string='';
    numberOfRows: number=0;
    numberOfColumns: number=0;
    availablePlaces: number=0;
}
