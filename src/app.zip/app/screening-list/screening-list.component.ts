import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Screening } from '../screening';
import { ScreeningService } from '../screening.service';
import { MovieService } from '../movie.service';
import {AuthService} from '../auth.service';

@Component({
  selector: 'screening-list',
  templateUrl: './screening-list.component.html',
  styleUrls: ['./screening-list.component.css']
})
export class ScreeningListComponent implements OnInit {
  screenings: Screening[] = []
  filteredScreenings = [];
  selectedDType = '2D';
  selectedScreening = null;
  id: number=null;
  title="Vetítések listája";
  @Input() showAdd = true;
  constructor(private screeningService: ScreeningService,
    authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private movieService:MovieService) { }

  async ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.id = +id;
      console.log(id)
      this.screenings= await this.movieService.getScreeningsToMovie(this.id);
      this.title = 'A kiválasztott filmhez tartozo vetitesek: ';
      
    }else{
    this.screenings = await this.screeningService.getScreenings();
    }
    this.filterScreenings();
  }
  filterScreenings() {
    this.filteredScreenings = this.selectedDType === ''
      ? this.screenings
      : this.screenings.filter(screening => screening.dType === this.selectedDType);
  }

  onFilterChange(data) {
    this.selectedDType = data;
    this.filterScreenings();
  }

}
