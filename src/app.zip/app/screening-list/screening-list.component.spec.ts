import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScreeningListComponent } from './screening-list.component';

describe('ScreeningListComponent', () => {
  let component: ScreeningListComponent;
  let fixture: ComponentFixture<ScreeningListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScreeningListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScreeningListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
